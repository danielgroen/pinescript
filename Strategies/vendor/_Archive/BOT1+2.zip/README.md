# pinescript
collection of my scripts

## Alert logica
🟢⚫️ 🤖 ⚪️🔮

🔮=future
⚪️=spot

🟢=Kucoin
⚫️=Bybit


🤖=bot


▲▼=long/short
▼=long
▼=short

@daviddtech Strategies 
https://clever-rose-976.notion.site/a5d9bd83b0bd4914b68e6f0e29fbb92c?v=bf8fce2c28d64550831eb0adc3707de7

https://members.davidd.tech/home


WISE WORDS FROM VLAD:
when a strat works on different exchanges it is a big sign that the strategy isnt overfitted
so... if i found THE strategy. watch the backtest results for diff exchanges as well.. e.d:
you have a strat for BTCUSDT on bybit. have a look at it on BTCUSDT on binance broker