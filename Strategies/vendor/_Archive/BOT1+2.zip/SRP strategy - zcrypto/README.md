# SRP strategy - zcrypto

## Alert name:
⚫️       🤖 | BY[BOT2] | ▲▼ | [SRP Strategy] $100

## Timeframe:
15M

## Symbol:
XLMUSDT

## Broker:
BYBIT

## Since:
4 SEPTEMBER 2023