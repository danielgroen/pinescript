# Zendog V3 backtest DCA bot 3commas

## Alert name:
⚫️       🤖 | BY[BOT1] | ▲ | [Zendog DCA] $100

## Timeframe:
15M

## Symbol:
DOGEUSDT

## Broker:
BYBIT

## Since:
19 SEPTEMBER 2023