# Pivots bot 15min-2hours

## Alert name:
⚫️       🤖 | BY[BOT2] | ▲▼ | [Pivots bot 15min-2h] $100

## Url
https://www.tradingview.com/v/yx1GnKvK/

## Timeframe:
15MIN

## Symbol:
ADAUSDT

## Broker:
BYBIT

## Since:
18 SEPTEMBER 2023