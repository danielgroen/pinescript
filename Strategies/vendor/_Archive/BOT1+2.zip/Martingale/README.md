# Martingale

## Alert name:
⚫️       🤖 | BY[BOT2] | ▲ | [Martingale] $100

## Url
https://www.tradingview.com/v/yx1GnKvK/

## Timeframe:
15MIN

## Symbol:
SOLUSDT

## Broker:
BYBIT

## Since:
15 SEPTEPBER 2023
