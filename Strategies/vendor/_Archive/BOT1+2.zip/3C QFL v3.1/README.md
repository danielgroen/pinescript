# 3C QFL

## Alert name:
⚫️       🤖 | BY[BOT1] | ▲ | [3C QFL v3.1] $100

## Timeframe:
15M

## Symbol:
SOLUSDT

## Broker:
BYBIT

## Since:
16 OCTOBER 2023