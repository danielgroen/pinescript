# Smart Money + ABC STRAT [v4] by @DaviddTech

## Alert name:
⚫️       🤖 | BY[BOT2] | ▲▼ | [Smart Money + ABC STRAT] | $100

## Url
https://www.tradingview.com/v/VpQop3tN/

## Timeframe:
15MIN

## Symbol:
BTCUSDT

## Broker:
BYBIT

## Since:
18 SEPTEMBER 2023