# BB + Aroon [Alorse]

## Alert name:
⚫️       🤖 | BY[BOT2] | ▲▼ | [BB+Aroon] | $100

## Timeframe:
30M

## Symbol:
DOGEUSDT

## Broker:
BYBIT

## Since:
31 AUGUST 2023
