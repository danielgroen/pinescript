# DCA - BNB 15min

## Alert name:
⚫️       🤖 | BY[BOT2] | ▲▼ | [DCA - BNB 15min] | $100

## Timeframe:
15M

## Symbol:
XRPUSDT

## Broker:
BYBIT

## Since:
9 OCTOBER 2023