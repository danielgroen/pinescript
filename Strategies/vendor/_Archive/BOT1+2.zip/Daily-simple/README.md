# 30min candle simple reversal strat

## Alert name:
⚫️       🤖 | BY[BOT1] | ▲▼ | [Daily-simple] | $100

## URL
https://www.tradingview.com/v/VMoiU3AH/

## Timeframe:
15M

## Symbol:
DOTUSDT

## Broker:
BYBIT

## Since:
16 OCTOBER 2023