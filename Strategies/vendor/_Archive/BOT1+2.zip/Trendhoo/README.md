# 🚀 Trendhoo [v5] by @DaviddTech 🤖

## Alert name:
⚫️       🤖 | BY[BOT1] | ▲▼ | [Trendhoo] | $100

## URL
https://www.tradingview.com/v/O5oEe5je/

## Timeframe:
15MIN

## Symbol:
ETHUSDT

## Broker:
BYBIT

## Since:
5 OCTOBER 2023