# Super 8 - 30M BTC

## Alert name:
⚫️       🤖 | BY[BOT1] | ▲▼ | [Super 8] | $100

## Timeframe:
15M

## Symbol:
XRPUSDT

## Broker:
BYBIT

## Since:
31 AUGUST 2023