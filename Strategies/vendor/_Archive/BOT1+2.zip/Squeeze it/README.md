# 30min candle simple reversal strat

## Alert name:

## URL

## Timeframe:

## Symbol:

## Broker:

## Since: