# 3Commas Visible DCA Strategy

## Alert name:
⚫️       🤖 | BY[BOT1] | ▲ | [3Commas Visible DCA] $100

## Timeframe:
15M

## Symbol:
LTCUSDT

## Broker:
BYBIT

## Since:
2 OCTOBER 2023