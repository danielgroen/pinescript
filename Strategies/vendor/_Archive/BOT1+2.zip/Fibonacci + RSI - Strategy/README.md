# Fibonacci + RSI - Strategy

## Alert name:
⚫️       🤖 | BY[BOT1] | ▲▼ | [Fibonacci + RSI] | $100

## Timeframe:
15M

## Symbol:
XLMUSDT

## Broker:
BYBIT

## Since:
31 AUGUST 2023
