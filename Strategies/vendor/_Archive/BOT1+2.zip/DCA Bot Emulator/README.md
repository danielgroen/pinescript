# DCA Bot Emulator

## Alert name:
⚫️       🤖 | BY[BOT1] | ▲ | [DCA Bot emulator] $100

## Timeframe:
15M

## Symbol:
OPUSDT

## Broker:
BYBIT

## Since:
3 OCTOBER 2023