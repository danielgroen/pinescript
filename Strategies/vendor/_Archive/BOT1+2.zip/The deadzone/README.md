# THE DEAD ZONE [v5] 🧠 by @DaviddTech 🤖

## Alert name:
⚫️       🤖 | BY[BOT1] | ▲▼ | [Dead zone @daviddtech] $100

## Url
https://www.tradingview.com/v/to36sTrS/

## Timeframe:
15MIN

## Symbol:
BTCUSDT

## Broker:
BYBIT

## Since:
26 SEPTEMBER 2023