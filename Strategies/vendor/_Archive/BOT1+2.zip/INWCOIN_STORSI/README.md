# inwCoin Sto RSI Bullish/Bearish Divergence + Scalping Strategy

## Alert name:
⚫️       🤖 | BY[BOT1] | ▼ | [INWCOIN_STORSI] $100

## URL
https://www.tradingview.com/v/jkg6wSxO/

## Timeframe:
15MIN

## Symbol:
ADA

## Broker:
BYBIT

## Since:
19 SEPTEMBER